# DigiHydro

Authors : James Joseph Luna, Patrick Francis Bajamunde, David Carlo Fermo

Emails : jjluna@gbox.adnu.edu.ph, pbajamunde@gbox.adnu.edu.ph, dfermo@gbox.adnu.edu.ph

## About
DigiHydro: A Real-time Monitoring Companion Application to Help Hydroponic Growers