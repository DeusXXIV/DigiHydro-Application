
enum Filter {
  six_hour,
  one_day,
  one_week,
  one_month,
  custom0,
  custom1
}