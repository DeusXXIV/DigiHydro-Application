
class Constant {
  static String air_temperature = "Temperature";
  static String water_temperature = "WaterTemperature";
  static String humidity = "Humidity";
  static String ph = "pH";
  static String tds = "TotalDissolvedSolids";
}